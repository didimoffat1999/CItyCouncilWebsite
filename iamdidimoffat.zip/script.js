const toggle = document.querySelector(".nav-toggle");
const nav = document.querySelector("#site-nav");
const form = document.querySelector("#contact-form");
const status = document.querySelector("#form-status");

toggle?.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  toggle.setAttribute("aria-expanded", String(open));
});

nav?.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    nav.classList.remove("open");
    toggle?.setAttribute("aria-expanded", "false");
  });
});

form?.addEventListener("submit", (event) => {
  event.preventDefault();
  const data = new FormData(form);
  const name = String(data.get("name") || "").trim();
  const email = String(data.get("email") || "").trim();
  const intent = String(data.get("intent") || "");
  const message = String(data.get("message") || "").trim();

  const subject = encodeURIComponent(`Campaign: ${intent} from ${name}`);
  const body = encodeURIComponent(
    `Name: ${name}\nEmail: ${email}\nInterest: ${intent}\n\n${message}`
  );

  window.location.href = `mailto:hello@iamdidimoffat.com?subject=${subject}&body=${body}`;

  status.hidden = false;
  status.textContent =
    "Your email app should open with a draft. If it does not, write hello@iamdidimoffat.com.";
});
